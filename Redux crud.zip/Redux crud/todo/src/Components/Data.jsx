export const userList = [
    {
        id:1,
        name:"Sudhishma",
        age: 29,
        place:"Kerala"

    },
    {   
        id:2,
        name:"Nandu",
        age: 22,
        place:"TN"

    },
    {
        id:3,
        name:"Ashley",
        age: 20,
        place:"Monaco"

    },
]